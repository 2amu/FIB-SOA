#include <circularbuff.h>
#include <io.h>

// Función para inicializar el buffer circular
void initCircularBuffer(struct CircularBuffer *buffer) {
    buffer->head = 0;
    buffer->escritos = 0;
    buffer->tail = 0;
}
int isEmptyCircularBuffer(struct CircularBuffer * buffer) {
    return buffer->escritos == 0;
}

int isFullCircularBuffer(struct CircularBuffer * buffer) {
    return buffer->escritos == CIRCULARBUFF_SIZE;
}

// Función para añadir un elemento al buffer circular
void addToCircularBuffer(struct CircularBuffer *buffer, char value) {
    if (!isFullCircularBuffer(buffer)) {
        buffer->vec[buffer->head] = value;
        buffer->head = (buffer->head + 1) % CIRCULARBUFF_SIZE;
        ++buffer->escritos;
    }
    //else printk("No puedo añadir mas");
}

// Función para leer un elemento del buffer circular
char readFromCircularBuffer(struct CircularBuffer *buffer) {
    if (!isEmptyCircularBuffer(buffer)) {
        char value = buffer->vec[buffer->tail];
        buffer->tail = (buffer->tail + 1) % CIRCULARBUFF_SIZE;
        --buffer->escritos;
        return value;
    }
    //else printk("No puedo leer mas");
}

