#include <libc.h>
#include <io.h>
#include <mm_address.h>
char buff[80];
char pantalla[25][80];
int pid, frames = 0;

/*void init_pantalla() {
  pantalla = {
    {'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
    {}
  }
}*/
void imprimirpantalla(){
  show_fps();
  for(int i = 0; i < 25; ++i) {
    gotoxy(0, i);
    write(1,pantalla[i], 80);
  }
  ++frames;
}

void show_fps() {
  if (gettime() > 18){
    int z = frames/(gettime()/18);
    itoa(z,buff);
    for(int j = 0; j < 80; ++j) pantalla[0][j] = buff[j];
  }
}

int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */
  //gotoxy(90,23);
  //int l = set_color(1,6); //fg, bg
  char buff[3];
  volatile int l = 0;
  //int x = read(buff, 5);
  //char buff2[256];
  //itoa(x,buff2);
  /*for (int j = 0; j < 1000000000; ++j) {
    if (j % 100000000 == 0) {
    int x = read(buff, 5);
    itoa(x,buff2);
    itoa(l,buff);
    //write(1,buff2,1);
    write(1,buff, 1);
    }
    }*/
  shmat(4, 100);
  shmrm(4);
  shmdt(4);//PAG_LOG_INIT_CODE+NUM_PAG_CODE+2*NUM_PAG_DATA);
  char buffff[26];

  int y = 1;
  int pid = fork();
  if (pid == 0) {
    y = 0;
    gotoxy(40, 20);
    itoa(y, buffff);
    write(1, buffff, strlen(buffff));
    //l = 3;
    //gettime();
    //write(1,"a",1);
    //exit();
    //int k = 8;
    //l = 3;
  }
  else{
    ++y;
    gotoxy(20, 20);
    itoa(y, buffff);
    write(1, buffff, strlen(buffff));

  }
  //exit();


  while(1) {
    //imprimirpantalla();
    //write(1,"a",1);
  }
}
